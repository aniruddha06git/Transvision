package com.aniruddha.transvision.Transvision;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransvisionApplicationTests {

	@Test
	void contextLoads() {
	}

}
