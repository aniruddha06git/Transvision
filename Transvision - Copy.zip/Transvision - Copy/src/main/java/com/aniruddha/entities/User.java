package com.aniruddha.entities;

import java.util.Iterator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.catalina.Group;
import org.apache.catalina.Role;
import org.apache.catalina.UserDatabase;

@Entity
@Table(name = "users")
public class User implements org.apache.catalina.User {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getFullName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setFullName(String fullName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Iterator<Group> getGroups() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator<Role> getRoles() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDatabase getUserDatabase() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addGroup(Group group) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addRole(Role role) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isInGroup(Group group) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isInRole(Role role) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void removeGroup(Group group) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeGroups() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeRole(Role role) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void removeRoles() {
		// TODO Auto-generated method stub
		
	}
    
    
	

}
