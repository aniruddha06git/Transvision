package com.aniruddha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aniruddha.entities.Book;

public interface BookRepository extends JpaRepository<Book, Long>{
	
	

}
