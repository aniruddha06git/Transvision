package com.aniruddha.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.aniruddha.entities.User;

public interface UserRepository extends JpaRepository<User, Long> {
	
	 User findByUsername(String username);

}
