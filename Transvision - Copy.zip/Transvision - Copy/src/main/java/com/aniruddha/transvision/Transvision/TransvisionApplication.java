package com.aniruddha.transvision.Transvision;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransvisionApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransvisionApplication.class, args);
	}

}
