package com.aniruddha.controller;

import com.aniruddha.service.UserService;

public class UserController {
	
	private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

}
