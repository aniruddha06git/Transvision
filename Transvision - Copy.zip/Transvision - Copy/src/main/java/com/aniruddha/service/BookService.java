package com.aniruddha.service;

import com.aniruddha.repository.BookRepository;

public class BookService {
	
	 private final BookRepository bookRepository;

	    public BookService(BookRepository bookRepository) {
	        this.bookRepository = bookRepository;
	    }

}
